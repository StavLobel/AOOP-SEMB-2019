package designPatterns;

public interface Observer {
	
	public boolean getNotified(Observable observable,String msg);
	
}
